'''Implement a class called player that represents a cricket player.The player class should have a
method called play() with prints "The player is playing cricket.derives two classes, batsman and
Bower,from the player class. override the play() method in each derived class to print"The Batsman
is batting"and "The bowler is bowling", respectively.write a program to create objects of both the
Batman and Bowler classes and call the play()method for each object.'''


#Define the base class player
class player:
  def play(self):
    print("The player is cricket.")

#Define the drived class Batsman
class Batsman(player):
  def play(self):
    print("The Batsman is batting.")

#Define the derived class Bowler
class Bowler(player):
  def play(self):
    print("The bowler is bowling.")

#create objects of Batsman and Bowler classes
batsman=Batsman()
bowler=Bowler()

#call the play() method for each object
batsman.play()
bowler.play()